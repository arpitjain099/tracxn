<!DOCTYPE html>
<html>
<head>
    <title>404 - Page Not Found</title>
    <link rel="stylesheet" href="http://s3.amazonaws.com/tracxnassets/assets/tracxn-1.1/404-5929b9687a6e823ff0afa8f7f8d68d19.css"/>
    <link href='http://fonts.googleapis.com/css?family=Nothing+You+Could+Do' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="text-center img-pad">
    <div>
        <h1>Page not found!</h1>
    </div>
    <img src="/images/404.jpg" width="40%">
    <div class="center-it text-center" style="width:500px;">
        <div class="btn btn-dark"><a href="javascript:history.back()">BACK</a></div>
        <div class="btn btn-dark"><a href="/user/dashboard">DASHBOARD</a></div>
    </div>
</div>


  


<script src="http://s3.amazonaws.com/tracxnassets/assets/tracxn-1.1/jquery-1.11.0.min-b1c6dee25fcae56686711d5f32b2ef23.js" type="text/javascript" ></script>
<script src="http://s3.amazonaws.com/tracxnassets/assets/tracxn-1.1/bootstrap-2eea82ccd3bb50c761b6b53158377a38.js" type="text/javascript" ></script>
<script src="http://s3.amazonaws.com/tracxnassets/assets/tracxn-1.1/header-3a21bafc27d7abfb8534ba36711c52f3.js" type="text/javascript" ></script>
</body>
</html>
